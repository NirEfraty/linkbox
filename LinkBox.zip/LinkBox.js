define(["qlik", "./getMasterItems", "css!./style.css"], function (qlik, getMasterItems) {
	return {
		initialProperties: {			
		},
		definition: {
			type: "items",
			component: "accordion",
			items: {
				DialogList: {
				    label: "Dialog",
					type: "items",
					items: {
						DialogTitle: {
							ref: "dialogtitle",
							label: "Dialog Title",
							type: "string",
							defaultValue: "Title",
							expression: "optional"
						},
						ButtonText: {
							ref: "ButtonText",
							label: "Button Text",
							type: "string",
							defaultValue: "View Dialog",
							expression: "optional"
						},
						Dialogwidth: {
							ref: "dialogwidth",
							label: "Dialog Width in %",
							type: "string",
							defaultValue: "50",
							expression: "optional"
						},
						Dialogheight: {
							ref: "Dialogheight",
							label: "Dialog Height in px",
							type: "string",
							defaultValue: "300",
							expression: "optional"
						},
						defaultMasterObject: {
							type: "string",
							component: "dropdown",
							label: "Master Object",
							ref: "defaultMasterObject",
							options: function () {
								return getMasterItems().then(function (items) {
									return items;
								});
							}
						},
						ShowPara: {
							type: "boolean",
							label: "Add HTML Paragraph",
							ref: "ShowPara",
							defaultValue: false
						},
						Paragraph: {
							label: "HTML Paragraph",
							component: "textarea",
							rows: 7,
							maxlength: 100000,
							ref: "Paragraph",
							expression: "optional",
							show: function (d) {
								return d.ShowPara;
							}
						},
						Paragraphheight: {
							ref: "Paragraphheight",
							label: "Paragraph Height in px",
							type: "string",
							defaultValue: "300",
							expression: "optional",
							show: function (d) {
								return d.ShowPara;
							}
						},
						// end
					}
				},
				//end
				settings: {
					uses: "settings",
					items: {
						DialogSettings:{
							label:"Dialog Settings",
							type:"items",
							items:{
								ShowDialogTitle: {
									type: "boolean",
									label: "Show Dialog Title",
									ref: "ShowDialogTitle",
									defaultValue: true
								},
								ShowExport: {
									type: "boolean",
									label: "Show Export Button",
									ref: "ShowExport",
									defaultValue: true
								},
								LinkUrl: {
									type: "boolean",
									label: "Link popup:// URLs",
									ref: "LinkUrl",
									defaultValue: false
								},
								HideButton: {
									type: "boolean",
									label: "Hide Button",
									ref: "HideButton",
									defaultValue: false,
									show: function (d) {
										return d.LinkUrl;
									}
								}
							}
						}
						
					}
				}
			}
		}, 
		support: {
			snapshot: false,
			export: false,
			exportData: false
		},
		paint: function ($element, layout) {			
			
			var config = {
				host: window.location.hostname,
				prefix: "/",
				port: window.location.port,
				isSecure: window.location.protocol === "https:"
			},
				app = qlik.currApp(),
				sheetId = qlik.navigation.getCurrentSheetId().sheetId,
				layoutid = layout.qInfo.qId,
				htm = '',
				ShowDialogTitle = layout.ShowDialogTitle,
				ShowExport = layout.ShowExport,
				ShowClose = layout.ShowClose;
			
			if(layout.LinkUrl)
			{
				window.open = function (open) {
					return function (url, name, features) {
						var prefix = 'popup://' + layoutid;
						
						if(url.includes(prefix))
						{
							prefix = prefix + '?';
							
							try
							{
							
								var args = decodeURIComponent(url).substring(url.indexOf(prefix)).replace(prefix,'').split('&');

								args.forEach(function(e) {

									app.variable.setStringValue(e.split('=')[0], e.split('=')[1]);

								});
							}
							catch 
							{
								console.log('');
							}
							
							setTimeout(function(){ $('button[view-id="' + layoutid + '"]').trigger("click"); }, 500);							
						}
						else
						{
							return open.call(window, url, name, features);
						}
					};
				}(window.open);
			
			
			
				$('article').on('click', 'a',function( event ) {
				
					
					url = this.href.replace('http://','');
					
					var prefix = 'popup//' + layoutid;
						
					if(url.includes(prefix))
						{
							event.preventDefault();
							
							prefix = prefix + '?';
							
							try
							{
							
								var args = decodeURIComponent(url).substring(url.indexOf(prefix)).replace(prefix,'').split('&');

								args.forEach(function(e) {

									app.variable.setStringValue(e.split('=')[0], e.split('=')[1]);

								});
							}
							catch 
							{
								console.log('');
							}
							
							setTimeout(function(){ $('button[view-id="' + layoutid + '"]').trigger("click"); }, 500);							
						}
						
					});
					
			
			}

			// add html
			htm += '<div id="comment-diloag-' + layoutid + '" style="display: none;">';
			htm += '<div class="lui-dialog dialog-content"  style="">';
			htm += '<div class="lui-dialog__header" style="'+(ShowDialogTitle?'':'display:none;')+'">';
			htm += '  <div class="lui-dialog__title" id="Dialog-Title" ></div>';
			htm += '</div>';
			//lui-dialog__body
			htm += '<div class="lui-dialog__body2" id="cont-' + layoutid + '">';
			htm += '</div>';
			htm += '<div id="para-' + layoutid + '" style="height: auto;overflow: scroll;padding: 5px;margin: 5px;border: 1px solid #ccc;"></div>';
			htm += '<div class="lui-dialog__footer">';
			htm += '<a target="_blank" id="download_file" >Click here to download your data file.</a>';
			htm += '<button id="Export" class="lui-button  lui-dialog__button export" style="'+(ShowExport?'':'display:none;')+'"><i class="lui-icon  lui-icon--export" style="margin-right: 2px;"></i>Export</button>';
			htm += '<button class="lui-button  lui-dialog__button cancel" >Close</button>';
			htm += '</div>';
			htm += '</div>';
			htm += '</div>';
			if ($('#comment-diloag-' + layoutid).length == 0) {
				$('#grid-wrap').append(htm);
				$(function () {
					//{ containment: ".qv-panel-content" }
					$("#comment-diloag-" + layoutid).draggable({ handle: "div.lui-dialog__header" });
				});
			}
			
			var style = (layout.HideButton ? ' style="visibility:hidden" ' : '') + ' class="lui-button lui-dialog__button view_dialog" ';
			
			btn = '<button ' + style + ' view-id="' + layoutid + '">' + layout.ButtonText + '</button>';
			
			$element.html(btn);
			
			$(".cancel").click(function () {
				$('#comment-diloag-' + layoutid).css("display", "none");
				//$('#comment-diloag-' + layoutid).remove();
				//qlik.resize("comment-diloag-" + layoutid);
			});

			$(".view_dialog").click(function () {
				var obj = layout.defaultMasterObject;
				var width = layout.dialogwidth;
				var height = layout.Dialogheight;				
				var title = layout.dialogtitle;
				var ShowPara = layout.ShowPara;
				var Paragraph = layout.Paragraph;
				var Paragraphheight = layout.Paragraphheight;
				$('#download_file').hide();
				$("#comment-diloag-" + layoutid).css("left", "0");
				$("#comment-diloag-" + layoutid).css("top", "0");
				//console.log(obj, title, width, height);
				$('#Dialog-Title').html(title);
				$("#comment-diloag-" + layoutid).css("display", "");
				$(".dialog-content").css("width", width + "%");
				$("#cont-" + layoutid).css("height", height + "px");
				//console.log(obj,ShowPara,Paragraph);
				if (ShowPara == "false" || ShowPara === false) {
					$("#para-" + layoutid).hide();
				} else {
					$("#para-" + layoutid).show().css("height",Paragraphheight+"px").html(Paragraph);
				}
				app.getObject('cont-' + layoutid, obj).then(function (modal) {
					qlik.resize(this);
					// export data excel
					//console.log(modal);
					
					var title = modal.layout.qMeta.title;
					$('#Export').click(function () {
					
						var qTable = qlik.table(modal);
						
						var getBasePath = function() {
							var prefix = window.location.pathname.substr(0, window.location.pathname.toLowerCase().lastIndexOf("/sense") + 1),
								url = window.location.href;
							return url = url.split("/"), url[0] + "//" + url[2] + ("/" === prefix[prefix.length - 1] ? prefix.substr(0, prefix.length - 1) : prefix)
						}
						//qTable.exportData({download: true,filename:title});						
						modal.exportData().then(function (reply) {
											
							var a = document.createElement("a");
							document.body.appendChild(a);
							a.href = getBasePath() + reply.qUrl;
							a.download = "export.xlsx";
							a.click();
							document.body.removeChild(a)
							
							
						});
					});
				});
				
			});
			//needed for export
			return qlik.Promise.resolve();
		}
	};
});
